# Use the iter() function to convert the string below into an iterator:

s = 'hello'

s = iter(s)
print(next(s))