def my_func():
    print("Hey I am in module.py")