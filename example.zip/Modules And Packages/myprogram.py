from mymodule import my_func

my_func()