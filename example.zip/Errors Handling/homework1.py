"""
Handle the exception thrown by the code below by using try and except blocks.
"""

try:
    for i in ['a', 'b', 'c']:
        print(i**2)
except:
    print("This is wrong")