try:
    # Want to attempt this code
    # May have an error
    result = 10 + '10'
except:
    print('The error happened due to type mismatch')
else:
    print('Add went well')
    print(result)