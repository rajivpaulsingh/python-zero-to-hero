def cap_text(text):
    return text.title()  # replace .capitalize() with .title()
    # retuun text.capitalize() # replace only the first character