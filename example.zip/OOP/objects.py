# In Python, *everything is an object. 
# Remember from previous lectures we can use type() to check the type of object something is:
print(type(1))
print(type([]))
print(type(()))
print(type({}))